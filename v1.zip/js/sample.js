/* empty css    */
console.log("sample.js loaded");
