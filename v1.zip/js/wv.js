/* empty css    */
/* empty css       */
import "./guide3.js";
import { g as gsapWithCSS, S as ScrollTrigger } from "./animation.js";
import "./preload-helper.js";
const checkRes = (provide2) => {
  let isRes = void 0;
  window.w >= 768 ? provide2.res = "pc" : provide2.res = "mo";
  provide2.res = isRes;
  console.log(`window width size : ${w} 
window height size : ${h} 
window responsive : ${res} 
window location : ${loc}`);
  return isRes;
};
const checkScrollDir = () => {
  let preScrollTop = 0;
  $(window).on("scroll", () => {
    let nextScrollTop = window.scrollY;
    if (preScrollTop < nextScrollTop) {
      $("header").addClass("hide");
      $("body").addClass("scr_down").removeClass("scr_up");
    } else {
      $("header").removeClass("hide");
      $("body").removeClass("scr_down").addClass("scr_up");
    }
    preScrollTop = nextScrollTop;
  });
};
let provide = {
  w: $(window).innerWidth(),
  h: $(window).innerHeight(),
  res: void 0,
  loc: window.location.href
};
window.w = provide.w;
window.h = provide.h;
window.loc = provide.loc;
if (window.w >= 768) {
  window.res = "pc";
} else {
  window.res = "mo";
}
gsapWithCSS.registerPlugin(ScrollTrigger);
ScrollTrigger.config({ ignoreMobileResize: true, invalidateOnRefresh: true });
$(document).ready(function() {
  console.log(1, "document.ready");
});
$(window).on("resize", function() {
  ScrollTrigger.update();
});
checkRes(provide);
checkScrollDir();
